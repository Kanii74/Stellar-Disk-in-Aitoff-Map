An all-sky catalog of Galactic OB stars 
Citation: Reed C., 2003, AJ, 125, 2531
	  Reed C., 2005, AJ, 130, 1652

Data Taken from: http://cdsarc.u-strasbg.fr/ftp/cats/V/125/

The data file contains data in the following format:

Byte-by-byte Description of file: obcat.dat
--------------------------------------------------------------------------------
   Bytes Format Units   Label     Explanations
--------------------------------------------------------------------------------
   2-  6  I5    ---     ALS       Alma LS number (G1)
   8- 32  A25   ---     Name      Source name
  34- 41  A8    ---     DM        BD identifier:  BD, CD, or CP
  43- 51  A9    ---     CPD       CPD identifier
  53- 61  A9    ---     CD        Cordoba Durchmustering
  63- 68  I6    ---     SAO       ? SAO (Cat. I/131) number
  70- 75  I6    ---     HD        ? HD (Cat. III/135) number
  77- 80  I4    ---     HR        ? Bright Star (Cat. V/50) number
  82- 91  A10   ---     OName     ?=- Other name
  93- 97  F5.1  mag     mag       ?=99.9 magnitude, see n_mag
      99  A1    ---   n_mag       [PVN] Type of magnitude: V=pe, P=pg, N=none
 101-102  I2    h       RAh       Right Ascension J2000 (hours)
 104-105  I2    min     RAm       Right Ascension J2000 (minutes)
 107-110  F4.1  s       RAs       [0,60] Right Ascension J2000 (seconds)
     112  A1    ---     DE-       Declination J2000 (sign)
 113-114  I2    deg     DEd       Declination J2000 (degrees)
 116-117  I2    arcmin  DEm       Declination J2000 (minutes)
 119-120  I2    arcsec  DEs       [0,60] Declination J2000 (seconds)
 122-129  F8.2  deg     GLON      Galactic longitude
 131-138  F8.2  deg     GLAT      Galactic latitude
--------------------------------------------------------------------------------


